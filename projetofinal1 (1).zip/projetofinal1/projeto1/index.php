<?php

    include_once "topo.php";
    include_once "menu.php";

    // Conteúdo
    if(empty($_SERVER["QUERY_STRING"])){
        $var = "home"; // Página inicial do sistema
        include_once "$var.php";
    }elseif(isset($_GET['pg'])){ // Usar isset() para verificar se a variável existe
        $pg = $_GET['pg'];
        include_once "$pg.php";
    }else{
        echo "Página não encontrada";
    }

    include_once "rodape.php";
?>