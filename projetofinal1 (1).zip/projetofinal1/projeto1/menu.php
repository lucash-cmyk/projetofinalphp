<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="?pg=home">Troca Livros UNIPÊ</a>
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link active" href="?pg=home">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="?pg=cadastrar_livro">Doar/Trocar Livro</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="?pg=lista_livros">Livros Disponíveis</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="?pg=faleconosco">Fale Conosco</a>
            </li>
        </ul>
    </div>
</nav>