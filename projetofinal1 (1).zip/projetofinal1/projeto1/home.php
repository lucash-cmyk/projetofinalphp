<div class="container mt-4">
    <h2>Bem-vindo ao Troca Livros UNIPÊ!</h2>
    <p class="lead">Conectando alunos para a doação e troca de livros, ajudando a comunidade acadêmica e promovendo a sustentabilidade.</p>

    <div class="row">
        <div class="col-md-6">
            <div class="card bg-light p-3">
                <h4>Quero Doar ou Trocar!</h4>
                <p>Tem um livro de que não precisa mais? Cadastre-o e ajude um colega.</p>
                <a href="?pg=cadastrar_livro" class="btn btn-primary">Cadastrar Livro</a>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card bg-light p-3">
                <h4>Preciso de um Livro!</h4>
                <p>Procure na nossa lista de livros disponíveis e entre em contato com o doador.</p>
                <a href="?pg=lista_livros" class="btn btn-success">Ver Livros Disponíveis</a>
            </div>
        </div>
    </div>
</div>