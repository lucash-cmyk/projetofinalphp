<footer class="card">
    <div class="card-footer">Troca Livros UNIPÊ</div> 2025 &copy; Direitos Reservados UNIPÊ
</footer>

</body>
</html>