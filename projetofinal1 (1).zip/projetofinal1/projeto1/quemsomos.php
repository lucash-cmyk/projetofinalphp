<?php

    echo "<h3>Sobre o Projeto Troca Livros UNIPÊ</h3>";
?>

<p>O **Troca Livros UNIPÊ** é uma iniciativa da comunidade acadêmica que visa facilitar a doação e troca de materiais didáticos entre alunos de diversos cursos. Nosso objetivo é promover a sustentabilidade, reduzir custos e garantir que o conhecimento chegue a todos que precisam.</p>

<p>Utilize a plataforma para cadastrar livros que você já usou e que podem ser úteis para calouros ou colegas de outras fases. Você pode optar por doá-los ou trocá-los por outros materiais de seu interesse.</p>

<p>Contribuindo com o projeto, você ajuda a construir uma comunidade mais colaborativa e solidária na UNIPÊ.</p>