<?php:Roteador do Painel de Administração:admin/index.php
<?php
    // Inclua o arquivo de conexão. Ele deve estar na pasta anterior se você estiver na pasta admin.
    require_once '../config.inc.php';
    
    // Configuração do Painel
    echo "<h1>📚 Painel Administrativo - Troca Livros UNIPÊ</h1>";
?>

<nav>
    <!-- Link para a página principal (landing page) do projeto -->
    <a href="../index.php">⬅ Voltar para o Site Principal</a> | 
    <!-- Link para a página inicial do painel (principal.php) -->
    <a href="?pg=principal">Início do Painel</a> |
    <!-- Rota para a administração dos Livros (CRUD) -->
    <a href="?pg=livros-admin">Administrar Livros</a> |
    <a href="?pg=paginas-admin">Administrar Páginas</a> |
    <a href="?pg=contato-admin">Administrar Contatos</a>
</nav>
<hr>

<?php
    // Conteúdo
    if(empty($_SERVER["QUERY_STRING"])){
        // Se nenhuma página for especificada, carrega 'principal.php'
        $var = "principal"; 
        include_once "$var.php";
    }elseif(isset($_GET['pg'])){ // Usar isset() é uma boa prática
        $pg = $_GET['pg'];
        include_once "$pg.php";
    }else{
        echo "Página não encontrada";
    }
?>