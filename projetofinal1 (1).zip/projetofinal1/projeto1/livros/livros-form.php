<h1>📚 Cadastrar Livro para Doação/Troca</h1>
<form action="?pg=livros-cadastro" method="post">
    
    <label>Título do Livro</label>
    <input type="text" name="titulo" required><br><br>
    
    <label>Autor</label>
    <input type="text" name="autor" required><br><br>
    
    <label>Curso Relacionado (UNIPÊ)</label>
    <input type="text" name="curso" required><br><br>
    
    <label>Tipo de Oferta</label><br>
    <input type="radio" name="tipo" value="Doação" required> Doação <br>
    <input type="radio" name="tipo" value="Troca"> Troca <br><br>

    <label>Contato (Email/Telefone)</label>
    <input type="text" name="contato" required><br><br>

    <input type="submit" value="Cadastrar Livro">
</form>
<br>
<a href="?pg=livros-admin">⬅ Voltar</a>