<?php
require_once 'config.inc.php';

$id = $_GET['id'];

$sql = "SELECT * FROM livros WHERE id=$id";
$res = mysqli_query($conexao, $sql);
$livro = mysqli_fetch_array($res);

if(isset($_POST['atualizar'])){
    $titulo = $_POST['titulo'];
    $autor  = $_POST['autor'];
    $curso  = $_POST['curso'];
    $tipo   = $_POST['tipo'];

    $sql = "UPDATE livros SET titulo='$titulo',autor='$autor',curso='$curso',tipo='$tipo' WHERE id=$id";

    if(mysqli_query($conexao, $sql)){
        echo "<h2>Dados atualizados com sucesso!<h2>";
    }else{
        echo "Erro ao atualizar!";
    }
}
?>

<h2>✏ Editar Livro</h2>

<form method="POST">
    Título: <input type="text" name="titulo" value="<?=$livro['titulo']?>" required><br><br>
    Autor: <input type="text" name="autor" value="<?=$livro['autor']?>" required><br><br>
    Curso: <input type="text" name="curso" value="<?=$livro['curso']?>" required><br><br>

    Tipo:<br>
    <input type="radio" name="tipo" value="doação" <?=($livro['tipo']=='doação'?'checked':'')?> > Doação<br>
    <input type="radio" name="tipo" value="troca" <?=($livro['tipo']=='troca'?'checked':'')?> > Troca<br><br>

    <button type="submit" name="atualizar">Salvar alterações</button>
</form>

<br><a href="?pg=livros">⬅ Voltar</a>