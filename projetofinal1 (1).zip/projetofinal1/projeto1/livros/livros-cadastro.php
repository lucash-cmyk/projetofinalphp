<?php
    // Garante que o arquivo de conexão seja incluído.
    // Certifique-se de que 'config.inc.php' está no caminho correto.
    require_once 'config.inc.php';

    // 1. Processamento do Formulário (Ação de Salvar)
    if(isset($_POST['salvar'])){
        
        // Validação e Sanitização dos dados antes de usar na query
        $titulo = mysqli_real_escape_string($conexao, $_POST['titulo']);
        $autor  = mysqli_real_escape_string($conexao, $_POST['autor']);
        $curso  = mysqli_real_escape_string($conexao, $_POST['curso']);
        $tipo   = mysqli_real_escape_string($conexao, $_POST['tipo']);

        // 2. Query de Inserção na tabela 'livros'
        $sql = "INSERT INTO livros (titulo, autor, curso, tipo) 
                VALUES ('$titulo', '$autor', '$curso', '$tipo')";

        if(mysqli_query($conexao, $sql)){
            // Mensagem de sucesso
            echo "<div style='color: green; font-weight: bold;'>✅ Livro cadastrado com sucesso!</div>";
        }else{
            // Mensagem de erro com detalhe do MySQL
            echo "<div style='color: red; font-weight: bold;'>❌ Erro ao cadastrar! Detalhes: " . mysqli_error($conexao) . "</div>";
        }
    }
?>

<h2>📚 Cadastro de Livros - UNIPÊ</h2>

<form method="POST">
    
    <label for="titulo">Título:</label>
    <input type="text" id="titulo" name="titulo" required><br><br>
    
    <label for="autor">Autor:</label>
    <input type="text" id="autor" name="autor" required><br><br>
    
    <label for="curso">Curso relacionado:</label>
    <input type="text" id="curso" name="curso" required><br><br>
    
    <label>Tipo:</label><br>
    <input type="radio" id="doacao" name="tipo" value="Doação" required> 
    <label for="doacao">Doação</label> <br>
    
    <input type="radio" id="troca" name="tipo" value="Troca"> 
    <label for="troca">Troca</label> <br><br>
    
    <button type="submit" name="salvar">Salvar Cadastro</button>
</form> 

<br>
<a href="?pg=livros-admin">⬅ Voltar para a Administração de Livros</a>