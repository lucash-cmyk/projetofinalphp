<?php
require_once 'config.inc.php';

$id = $_GET['id'];

$sql = "DELETE FROM livros WHERE id=$id";

if(mysqli_query($conexao, $sql)){
    echo "<script>alert('Livro removido!');location='?pg=livros';</script>";
}else{
    echo "Erro ao excluir!";
}