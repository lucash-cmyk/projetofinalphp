<?php
    // Inclua o arquivo de configuração e conexão com o banco de dados
    // require_once "admin/config.inc.php";

    // Lógica PHP para processar o formulário (Inserção no Banco de Dados)
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Exemplo básico de coleta de dados. É essencial ADICIONAR VALIDAÇÃO E SANITIZAÇÃO!
        $titulo = $_POST['titulo'];
        $autor = $_POST['autor'];
        $curso = $_POST['curso'];
        $tipo = $_POST['tipo'];
        $contato = $_POST['contato'];

        // Exemplo de INSERT (depende da sua tabela 'livros')
        /*
        $sql = "INSERT INTO livros (titulo, autor, curso, tipo, contato) VALUES ('$titulo', '$autor', '$curso', '$tipo', '$contato')";
        if (mysqli_query($conexao, $sql)) {
            echo '<div class="alert alert-success mt-3">Livro cadastrado com sucesso!</div>';
        } else {
            echo '<div class="alert alert-danger mt-3">Erro ao cadastrar o livro: ' . mysqli_error($conexao) . '</div>';
        }
        */
        echo '<div class="alert alert-info mt-3">Funcionalidade de cadastro em desenvolvimento. Dados recebidos: Título: ' . $titulo . '</div>';
    }
?>

<div class="container mt-4">
    <h3>Doar ou Trocar um Livro</h3>
    <form method="POST" action="?pg=cadastrar_livro">
        <div class="mb-3 mt-3">
            <label for="titulo" class="form-label">Título do Livro:</label>
            <input type="text" class="form-control" id="titulo" placeholder="Ex: Cálculo I" name="titulo" required>
        </div>
        <div class="mb-3">
            <label for="autor" class="form-label">Autor:</label>
            <input type="text" class="form-control" id="autor" placeholder="Ex: James Stewart" name="autor" required>
        </div>
        <div class="mb-3">
            <label for="curso" class="form-label">Curso de Interesse (UNIPÊ):</label>
            <input type="text" class="form-control" id="curso" placeholder="Ex: Engenharia Civil, Direito" name="curso">
        </div>
        <div class="mb-3">
            <label for="tipo" class="form-label">Tipo de Oferta:</label>
            <select class="form-select" id="tipo" name="tipo" required>
                <option value="Doação">Doação</option>
                <option value="Troca">Troca</option>
            </select>
        </div>
        <div class="mb-3">
            <label for="contato" class="form-label">E-mail ou Telefone de Contato (UNIPÊ):</label>
            <input type="text" class="form-control" id="contato" placeholder="Seu contato UNIPÊ" name="contato" required>
        </div>
        <button type="submit" class="btn btn-primary">Cadastrar Livro</button>
    </form>
</div>