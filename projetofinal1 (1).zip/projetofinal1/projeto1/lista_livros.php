<?php
    // Inclua o arquivo de configuração e conexão com o banco de dados
    // require_once "admin/config.inc.php";

    // Exemplo de SELECT (Ajuste o nome da sua tabela)
    /*
    $sql = "SELECT titulo, autor, curso, tipo, contato FROM livros ORDER BY titulo ASC";
    $resultado = mysqli_query($conexao,$sql);
    */

    // Dados de exemplo para simulação (remover quando conectar ao BD)
    $livros_exemplo = [
        ['titulo' => 'Introdução à Programação', 'autor' => 'Algoritmo da Silva', 'curso' => 'Ciência da Computação', 'tipo' => 'Doação', 'contato' => 'aluno@unipe.br'],
        ['titulo' => 'Direito Civil - Vol. 1', 'autor' => 'Jurídico de Souza', 'curso' => 'Direito', 'tipo' => 'Troca', 'contato' => 'juridico@unipe.br'],
        ['titulo' => 'Anatomia Humana', 'autor' => 'Médico dos Santos', 'curso' => 'Medicina', 'tipo' => 'Doação', 'contato' => 'medico@unipe.br']
    ];
?>
<div class="container mt-3">
    <h2>Livros Disponíveis para Doação/Troca</h2>
    <p>Use o contato fornecido para solicitar o livro diretamente ao doador.</p>
    <table class="table table-striped table-hover">
        <thead class="table-dark">
        <tr>
            <th>Título</th>
            <th>Autor</th>
            <th>Curso Relacionado</th>
            <th>Oferta</th>
            <th>Contato</th>
        </tr>
        </thead>
        <tbody>
        <?php
            // while($dados = mysqli_fetch_array($resultado)){ // Use esta linha quando conectar ao BD
            foreach($livros_exemplo as $dados){ // Use esta linha para o exemplo
        ?>

        <tr>
            <td><?=$dados['titulo']?></td>
            <td><?=$dados['autor']?></td>
            <td><?=$dados['curso']?></td>
            <td>
                <?php
                    // Destaca se for Doação ou Troca
                    $badge_class = ($dados['tipo'] == 'Doação') ? 'bg-success' : 'bg-warning text-dark';
                ?>
                <span class="badge <?=$badge_class?>"><?=$dados['tipo']?></span>
            </td>
            <td><a href="mailto:<?=$dados['contato']?>"><?=$dados['contato']?></a></td>
        </tr>
        <?php
            }
        ?>
        </tbody>
    </table>
</div>